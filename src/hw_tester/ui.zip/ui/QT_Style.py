import sys
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex
from PySide6.QtGui import QFont, QTextCharFormat, QColor, QTextCursor
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QTableView, QTextEdit, QPushButton, QComboBox, QLineEdit, QCheckBox,
    QGroupBox, QLabel, QSizePolicy, QSpacerItem
)

# ----------- STYLE HELPER -----------
def load_stylesheet(app, path):
    path = Path(path)
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            app.setStyleSheet(f.read())
        print(f"Loaded stylesheet: {path}")
    else:
        print(f"Stylesheet not found: {path}")
# ------------------------------------


HEADERS = [
    "ID", "Connector", "Discrete_Name", "Signal_Name", "Plug", "Type", "Pin",
    "Power_Expected", "Power_Input", "Power_Result", "PullUp_Expected", "Logic_Expected"
]

SAMPLE_ROWS = [
    [13, "J5", "AI_8", "THREAT_INT_KNOB_(TWS)", "IP2", "0-10 Vdc", "TB4.1", 10.00, "P", "No Result", 0.00, "No Result"],
    [24, "J5", "DI_1", "X1_EWD_(EWD)", "IP1", "Gnd/open", "3", 3.50, "", "No Result", 0.00, "No Result"],
    [25, "J5", "DO_1", "Y2_EWD_(EWD)", "IP1", "GND/open", "4", 0.00, "", "No Result", 21.00, "Expected"],
    [26, "J5", "DO_2", "Y3_EWD_(EWD)", "IP1", "GND/open", "6", 0.00, "", "No Result", 21.00, "Expected"],
    [27, "J5", "DI_28", "IFF_IDENT_PB", "IP2", "Gnd/open", "23", 3.50, "", "No Result", 0.00, "No Result"],
]


class SimpleTableModel(QAbstractTableModel):
    def __init__(self, headers, rows):
        super().__init__()
        self._headers = headers
        self._rows = rows

    def rowCount(self, parent=QModelIndex()):
        return len(self._rows)

    def columnCount(self, parent=QModelIndex()):
        return len(self._headers)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None

        row = index.row()
        col = index.column()
        value = self._rows[row][col]

        if role == Qt.DisplayRole:
            return str(value)

        if role == Qt.TextAlignmentRole:
            if isinstance(value, (int, float)):
                return Qt.AlignRight | Qt.AlignVCenter
            return Qt.AlignLeft | Qt.AlignVCenter

        if role == Qt.BackgroundRole:
            header = self._headers[col]
            if header in ("Power_Result", "Logic_Expected"):
                s = str(value).lower()
                if "fail" in s or "error" in s:
                    return QColor(255, 230, 230)
                if "pass" in s or "success" in s or "expected" in s:
                    return QColor(230, 255, 230)
                if "no result" in s:
                    return QColor(245, 245, 245)

        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return self._headers[section]
        return str(section + 1)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("HW Tester - ControllinoMega (PySide6 minimal)")
        self.resize(1300, 750)

        root = QWidget()
        self.setCentralWidget(root)

        main_layout = QVBoxLayout(root)

        # -------- TABLE --------
        self.table = QTableView()
        self.model = SimpleTableModel(HEADERS, SAMPLE_ROWS)
        self.table.setModel(self.model)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        main_layout.addWidget(self.table, stretch=6)

        # -------- CONTROLS --------
        controls_row = QHBoxLayout()

        left_group = QGroupBox("Connector / File")
        left_layout = QGridLayout(left_group)
        self.connector_edit = QLineEdit("J5_AFT_")

        self.btn_load = QPushButton("Load")

        # ✅ Added: set object name so QSS can style it as primary
        self.btn_load.setObjectName("btnPrimary")

        left_layout.addWidget(QLabel("Connector:"), 0, 0)
        left_layout.addWidget(self.connector_edit, 0, 1)
        left_layout.addWidget(self.btn_load, 1, 1)
        controls_row.addWidget(left_group)

        main_layout.addLayout(controls_row)

        # -------- LOG --------
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setFont(QFont("Consolas", 10))

        # ✅ Added: set object name so QSS can style the log window
        self.log.setObjectName("logWindow")

        main_layout.addWidget(self.log, stretch=3)

        self.add_log("INF", "App started")

    def add_log(self, level, message):
        ts = datetime.now().strftime("%H:%M:%S")
        cursor = self.log.textCursor()
        cursor.movePosition(QTextCursor.End)

        fmt = QTextCharFormat()
        if level == "ERR":
            fmt.setForeground(QColor("red"))
        elif level == "SUC":
            fmt.setForeground(QColor("green"))

        cursor.insertText(f"[{ts}] [{level}] {message}\n", fmt)


# -------- MAIN --------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    # 🔥 LOAD STYLE HERE
    load_stylesheet(app, Path(__file__).parent / "Styles" / "dark.qss")

    w = MainWindow()
    w.show()
    sys.exit(app.exec())
