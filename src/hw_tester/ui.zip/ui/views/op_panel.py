"""
OperationalPanel component - Connector label and action buttons.
"""
import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional, Dict
import os
import glob


class OperationalPanel(tk.Frame):
    """
    Operational panel with connector label and action buttons.
    Layout: connector_label | Load | Sim dropdown | HTML Files | Debug | HW dropdown | I_Bit | ClearLog | Report (row 0)
            (rowspan=2)     | (empty) | Localhost | Next | (empty) | KeepAlive | Stop_IBIT | Log Filter checkboxes (row 1)
            (empty)         | Test (2x width) | Stop_T (2x width) | ... (row 2)
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        on_load: Optional[Callable[[], None]] = None,
        on_keep_alive: Optional[Callable[[], None]] = None,
        on_i_bit: Optional[Callable[[], None]] = None,
        on_test: Optional[Callable[[], None]] = None,
        on_test_all: Optional[Callable[[], None]] = None,
        on_doc: Optional[Callable[[], None]] = None,
        on_stop_ibit: Optional[Callable[[], None]] = None,
        on_stop_t: Optional[Callable[[], None]] = None,
        on_report: Optional[Callable[[], None]] = None,
        on_clear_log: Optional[Callable[[], None]] = None,
        settings: Optional[Dict] = None,
        on_hw_change: Optional[Callable[[str], None]] = None,
        on_simulate_change: Optional[Callable[[str], None]] = None,
        on_iobox_change: Optional[Callable[[str], None]] = None,
        on_log_filter_change: Optional[Callable[[str], None]] = None,
        on_localhost_change: Optional[Callable[[str], None]] = None,
        on_next: Optional[Callable[[], None]] = None,
        on_html_file_change: Optional[Callable[[str], None]] = None,
        on_debug_change: Optional[Callable[[str], None]] = None
    ):
        """
        Initialize OperationalPanel.
        
        Args:
            parent: Parent tkinter widget
            on_load: Callback for Load button
            on_keep_alive: Callback for KeepAlive button
            on_i_bit: Callback for I_Bit button
            on_test: Callback for Test button
            on_test_all: Callback for Test_All button
            on_doc: Callback for DOC button
            on_stop_ibit: Callback for Stop_IBIT button
            on_stop_t: Callback for Stop_T button
            on_report: Callback for Report button
            on_clear_log: Callback for ClearLog button
            settings: Settings dictionary from settings.yaml
            on_hw_change: Callback when hardware selection changes (receives new hw type)
            on_simulate_change: Callback when simulation mode changes (receives "Simulation On" or "Simulation Off")
            on_iobox_change: Callback when IO Box selection changes (receives new box type)
            on_log_filter_change: Callback when log filter selection changes (receives list of selected levels)
            on_localhost_change: Callback when localhost mode changes (receives "IO_box" or "Local Host")
            on_html_file_change: Callback when HTML file selection changes (receives filename or "none")
            on_debug_change: Callback when debug mode changes (receives "Debug" or "Normal")
        """
        super().__init__(parent)
        
        # Configure grid layout - multiple columns for new layout
        # Layout: connector_label | Load | Sim dropdown | HTML Files | Debug | HW dropdown | I_Bit | ClearLog | Report (row 0)
        #         (rowspan=2)     | (empty) | Localhost | Next | (empty) | KeepAlive | Stop_IBIT | Log Filter checkboxes (row 1)
        #         (empty)         | Test (2x width) | Stop_T (2x width) | ... (row 2)
        self.columnconfigure(0, weight=1)  # Connector label (resizable)
        for i in range(1, 12):  # Columns 1-11 for controls
            self.columnconfigure(i, weight=0)
        self.rowconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(2, weight=1)
        
        # Store callbacks
        self.on_load = on_load or (lambda: None)
        self.on_keep_alive = on_keep_alive or (lambda: None)
        self.on_i_bit = on_i_bit or (lambda: None)
        self.on_test = on_test or (lambda: None)
        self.on_test_all = on_test_all or (lambda: None)
        self.on_doc = on_doc or (lambda: None)
        self.on_stop_ibit = on_stop_ibit or (lambda: None)
        self.on_stop_t = on_stop_t or (lambda: None)
        self.on_report = on_report or (lambda: None)
        self.on_clear_log = on_clear_log or (lambda: None)
        self.on_hw_change = on_hw_change or (lambda hw: None)
        self.on_simulate_change = on_simulate_change or (lambda mode: None)
        self.on_iobox_change = on_iobox_change or (lambda box: None)
        self.on_log_filter_change = on_log_filter_change or (lambda level: None)
        self.on_localhost_change = on_localhost_change or (lambda mode: None)
        self.on_next = on_next or (lambda: None)
        self.on_html_file_change = on_html_file_change or (lambda file: None)
        self.on_debug_change = on_debug_change or (lambda mode: None)
        
        # Store settings
        self.settings = settings or {}
        
        # Create left side - Connector label (resized)
        label_frame = tk.Frame(self, relief=tk.SUNKEN, borderwidth=2)
        label_frame.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=(0, 10))
        
        self.connector_label = tk.Label(
            label_frame,
            text="Connector Name",
            font=("Arial", 12, "bold"),
            anchor=tk.W,
            padx=8,
            pady=8
        )
        self.connector_label.pack(fill=tk.BOTH, expand=True)
        
        # Define button styles
        self._setup_styles()
        
        # New Layout Implementation
        # Row 0: connector_label | Load | Sim dropdown | HTML Files | Debug | HW dropdown | I_Bit | Test | ClearLog | Report
        # Row 1: (connector_label spans) | (empty) | Localhost | Next | (empty) | KeepAlive | Stop_IBIT | Stop_T | Log Filter checkboxes
        
        # Column 1, Row 0: Load button
        self.btn_load = ttk.Button(
            self,
            text="Load",
            style="Secondary.TButton",
            command=self.on_load
        )
        self.btn_load.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        
        # Column 2, Row 0: Simulate dropdown
        board_config = self.settings.get('Board', {})
        current_simulation = board_config.get('simulation', False)
        simulate_mode = "Simulation On" if current_simulation else "Simulation Off"
        
        self.simulate_combo = ttk.Combobox(
            self,
            values=["Simulation On", "Simulation Off"],
            state="readonly",
            width=15
        )
        self.simulate_combo.set(simulate_mode)
        self.simulate_combo.bind('<<ComboboxSelected>>', self._on_simulate_changed)
        self.simulate_combo.grid(row=0, column=2, padx=5, pady=5, sticky="ew")
        
        # Column 2, Row 1: Localhost mode dropdown
        udp_settings = self.settings.get('UDP_Settings', {})
        current_localhost_mode = udp_settings.get('localhost_mode', False)
        localhost_display = "Local Host" if current_localhost_mode else "IO_box"
        
        self.localhost_combo = ttk.Combobox(
            self,
            values=["IO_box", "Local Host"],
            state="readonly",
            width=15
        )
        self.localhost_combo.set(localhost_display)
        self.localhost_combo.bind('<<ComboboxSelected>>', self._on_localhost_changed)
        self.localhost_combo.grid(row=1, column=2, padx=5, pady=5, sticky="ew")
        
        # Column 3, Row 1: Next button (always enabled, independent of debug mode)
        self.btn_next = ttk.Button(
            self,
            text="Next",
            style="Info.TButton",
            command=self.on_next,
            state=tk.NORMAL
        )
        self.btn_next.grid(row=1, column=3, padx=5, pady=5, sticky="ew")
        
        # Column 3, Row 0: HTML Files dropdown (enabled only in debug mode)
        debug_settings = self.settings.get('Debug', {})
        debug_mode = debug_settings.get('mode', False)
        html_dropdown_state = "readonly" if debug_mode else tk.DISABLED
        html_files = self._scan_html_files()
        
        self.html_combo = ttk.Combobox(
            self,
            values=html_files,
            state=html_dropdown_state,
            width=20
        )
        self.html_combo.set("none")
        self.html_combo.bind('<<ComboboxSelected>>', self._on_html_file_changed)
        self.html_combo.grid(row=0, column=3, padx=5, pady=5, sticky="ew")
        
        # Delete trace.json on startup to prevent displaying old data
        self._clear_trace_file()
        
        # Column 4, Row 0: Debug dropdown (Debug/Normal)
        current_debug = debug_settings.get('mode', False)
        debug_display = "Debug" if current_debug else "Normal"
        
        self.debug_combo = ttk.Combobox(
            self,
            values=["Debug", "Normal"],
            state="readonly",
            width=12
        )
        self.debug_combo.set(debug_display)
        self.debug_combo.bind('<<ComboboxSelected>>', self._on_debug_changed)
        self.debug_combo.grid(row=0, column=4, padx=5, pady=5, sticky="ew")
        
        # Column 4, Row 1: KeepAlive button
        self.btn_connect = ttk.Button(
            self,
            text="KeepAlive",
            style="Secondary.TButton",
            command=self.on_keep_alive
        )
        self.btn_connect.grid(row=1, column=5, padx=5, pady=5, sticky="ew")
        
        # Column 5, Row 0: Hardware dropdown
        available_types = board_config.get('AvailableTypes', ['ControllinoMega', 'ArduinoUno', 'none'])
        current_type = board_config.get('Type', 'ControllinoMega')
        
        self.hw_combo = ttk.Combobox(
            self,
            values=available_types,
            state="readonly",
            width=15
        )
        self.hw_combo.set(current_type)
        self.hw_combo.bind('<<ComboboxSelected>>', self._on_hw_changed)
        self.hw_combo.grid(row=0, column=5, padx=5, pady=5, sticky="ew")
        
        # Column 5, Row 1: Stop_IBIT button
        self.btn_stop_ibit = ttk.Button(
            self,
            text="Stop_IBIT",
            style="Danger.TButton",
            command=self.on_stop_ibit,
            state=tk.DISABLED
        )
        self.btn_stop_ibit.grid(row=1, column=6, padx=5, pady=5, sticky="ew")
        
        # Column 6, Row 0: I_Bit button
        self.btn_i_bit = ttk.Button(
            self,
            text="I_Bit",
            style="Info.TButton",
            command=self.on_i_bit
        )
        self.btn_i_bit.grid(row=0, column=6, padx=5, pady=5, sticky="ew")
        
        # Row 2, Column 1: Test button
        self.btn_run = ttk.Button(
            self,
            text="Test",
            style="Primary.TButton",
            command=self.on_test
        )
        self.btn_run.grid(row=2, column=1, padx=5, pady=5, sticky="ew")

        # Row 2, Column 2: Test_All button
        self.btn_run_all = ttk.Button(
            self,
            text="Test_All",
            style="Primary.TButton",
            command=self.on_test_all
        )
        self.btn_run_all.grid(row=2, column=2, padx=5, pady=5, sticky="ew")
        
        # Row 2, Column 3: Stop_T button (2x width)
        self.btn_stop = ttk.Button(
            self,
            text="Stop_T",
            style="Danger.TButton",
            command=self.on_stop_t,
            state=tk.DISABLED
        )
        self.btn_stop.grid(row=2, column=3, columnspan=2, padx=5, pady=5, sticky="ew")
        
        # Column 7, Row 1: Log Filter checkboxes (spanning 2 columns)
        log_filter_frame = tk.LabelFrame(self, text="Log Filter", padx=3, pady=3)
        log_filter_frame.grid(row=1, column=8, columnspan=2, padx=5, pady=5, sticky="ew")
        
        self.log_filter_vars = {}
        log_levels = ["INFO", "SUCCESS", "WARNING", "ERROR", "DEBUG"]
        checkbox_frame = tk.Frame(log_filter_frame)
        checkbox_frame.pack()
        
        for idx, level in enumerate(log_levels):
            var = tk.BooleanVar(value=True)
            self.log_filter_vars[level] = var
            cb = tk.Checkbutton(
                checkbox_frame,
                text=level[:3] if level != "WARNING" else "WRN",
                variable=var,
                command=self._on_log_filter_changed
            )
            cb.pack(side=tk.LEFT, padx=2)
        
        # Column 8, Row 0: ClearLog button
        self.btn_clear_log = ttk.Button(
            self,
            text="ClearLog",
            style="Utility.TButton",
            command=self.on_clear_log
        )
        self.btn_clear_log.grid(row=0, column=8, padx=5, pady=5, sticky="ew")
        
        # Column 9, Row 0: Report button
        self.btn_report = ttk.Button(
            self,
            text="Report",
            style="Info.TButton",
            command=self.on_report
        )
        self.btn_report.grid(row=0, column=9, padx=5, pady=5, sticky="ew")

        # Column 10, Row 0: DOC button
        self.btn_doc = ttk.Button(
            self,
            text="DOC",
            style="Info.TButton",
            command=self.on_doc
        )
        self.btn_doc.grid(row=0, column=10, padx=5, pady=5, sticky="ew")
    
    def _scan_html_files(self) -> list:
        """
        Scan the web directory for .html files.
        
        Returns:
            List of HTML filenames (without path) plus "none" option
        """
        try:
            # Get the web directory path relative to this file
            current_dir = os.path.dirname(os.path.abspath(__file__))
            web_dir = os.path.join(current_dir, '..', '..', 'web')
            web_dir = os.path.normpath(web_dir)
            
            # Find all .html files
            html_pattern = os.path.join(web_dir, '*.html')
            html_paths = glob.glob(html_pattern)
            
            # Extract just the filenames (without path)
            html_files = [os.path.basename(path) for path in html_paths]
            html_files.sort()
            
            # Add "none" at the beginning
            return ["none"] + html_files
        except Exception as e:
            print(f"Error scanning HTML files: {e}")
            return ["none"]
    
    def _setup_styles(self) -> None:
        """Setup custom button styles."""
        style = ttk.Style()
        
        # Primary button (green for Test)
        style.configure("Primary.TButton", background="#28a745", foreground="black")
        style.map("Primary.TButton",
                  background=[("active", "#218838"), ("disabled", "#c3e6cb")])
        
        # Danger button (orange/red for Stop_T)
        style.configure("Danger.TButton", background="#fd7e14", foreground="black")
        style.map("Danger.TButton",
                  background=[("active", "#e36209"), ("disabled", "#ffc9a0")])
        
        # Secondary button (blue for KeepAlive)
        style.configure("Secondary.TButton", background="#007bff", foreground="black")
        style.map("Secondary.TButton",
                  background=[("active", "#0056b3"), ("disabled", "#99c9ff")])
        
        # Info button (gray for Report)
        style.configure("Info.TButton", background="#6c757d", foreground="black")
        style.map("Info.TButton",
                  background=[("active", "#545b62"), ("disabled", "#c6c9cc")])
        
        # Utility button (light for ClearLog)
        style.configure("Utility.TButton", background="#f8f9fa", foreground="black")
        style.map("Utility.TButton",
                  background=[("active", "#e2e6ea"), ("disabled", "#f8f9fa")])
    
    def _on_hw_changed(self, event) -> None:
        """Called when hardware dropdown selection changes."""
        new_hw = self.hw_combo.get()
        self.on_hw_change(new_hw)
    
    def _on_simulate_changed(self, event) -> None:
        """Called when simulate dropdown selection changes."""
        new_mode = self.simulate_combo.get()
        self.on_simulate_change(new_mode)
    
    def _on_localhost_changed(self, event) -> None:
        """Called when localhost mode dropdown selection changes."""
        new_mode = self.localhost_combo.get()
        self.on_localhost_change(new_mode)
    
    def _on_iobox_changed(self, event) -> None:
        """Called when IO Box dropdown selection changes."""
        # Note: IO Box dropdown removed from UI but code kept for future use
        # new_box = self.iobox_combo.get()
        # self.on_iobox_change(new_box)
        pass
    
    def _on_log_filter_changed(self) -> None:
        """Called when any log filter checkbox changes."""
        selected_levels = [level for level, var in self.log_filter_vars.items() if var.get()]
        self.on_log_filter_change(selected_levels)
    
    def _on_html_file_changed(self, event) -> None:
        """Called when HTML file dropdown selection changes."""
        new_file = self.html_combo.get()
        self.on_html_file_change(new_file)
    
    def _on_debug_changed(self, event) -> None:
        """Called when debug mode dropdown selection changes."""
        new_mode = self.debug_combo.get()
        self.on_debug_change(new_mode)
        # Update HTML dropdown state based on debug mode
        is_debug = (new_mode == "Debug")
        self.html_combo.config(state="readonly" if is_debug else tk.DISABLED)
    
    def _clear_trace_file(self) -> None:
        """Reset trace.json on startup to prevent displaying old data."""
        try:
            import json
            import time
            current_dir = os.path.dirname(os.path.abspath(__file__))
            trace_file = os.path.join(current_dir, '..', '..', 'web', 'trace.json')
            trace_file = os.path.normpath(trace_file)
            
            # Write a reset state instead of deleting
            reset_data = {"key": 0, "status": "none", "ts": time.time()}
            with open(trace_file, 'w', encoding='utf-8') as f:
                json.dump(reset_data, f)
            
            print(f"✓ Reset trace.json on startup: {trace_file}")
        except Exception as e:
            print(f"Warning: Could not reset trace.json: {e}")
    
    def set_connector(self, name: str) -> None:
        """
        Set the connector name displayed in the label.
        
        Args:
            name: Connector name to display
        """
        self.connector_label.config(text=name)
    
    def enable_stop_t(self, enabled: bool = True) -> None:
        """Enable or disable the Stop_T button."""
        self.btn_stop.config(state=tk.NORMAL if enabled else tk.DISABLED)
    
    def enable_stop_ibit(self, enabled: bool = True) -> None:
        """Enable or disable the Stop_IBIT button."""
        self.btn_stop_ibit.config(state=tk.NORMAL if enabled else tk.DISABLED)
    
    def enable_test(self, enabled: bool = True) -> None:
        """Enable or disable the Test button."""
        self.btn_run.config(state=tk.NORMAL if enabled else tk.DISABLED)

    def enable_test_all(self, enabled: bool = True) -> None:
        """Enable or disable the Test_All button."""
        self.btn_run_all.config(state=tk.NORMAL if enabled else tk.DISABLED)
    
    def enable_i_bit(self, enabled: bool = True) -> None:
        """Enable or disable the I_Bit button."""
        self.btn_i_bit.config(state=tk.NORMAL if enabled else tk.DISABLED)
    
    def enable_load(self, enabled: bool = True) -> None:
        """Enable or disable the Load button."""
        self.btn_load.config(state=tk.NORMAL if enabled else tk.DISABLED)
    
    def enable_keep_alive(self, enabled: bool = True) -> None:
        """Enable or disable the KeepAlive button."""
        self.btn_connect.config(state=tk.NORMAL if enabled else tk.DISABLED)
    
    def get_hardware(self) -> str:
        """Get the selected hardware type."""
        return self.hw_combo.get()
    
    def set_hardware(self, hw: str) -> None:
        """Set the hardware type."""
        self.hw_combo.set(hw)
    
    def get_simulation_mode(self) -> str:
        """Get the simulation mode (On/Off)."""
        return self.simulate_combo.get()
    
    def set_simulation_mode(self, mode: str) -> None:
        """Set the simulation mode."""
        self.simulate_combo.set(mode)
    
    def get_localhost_mode(self) -> str:
        """Get the localhost mode (IO_box/Local Host)."""
        return self.localhost_combo.get()
    
    def set_localhost_mode(self, mode: str) -> None:
        """Set the localhost mode (IO_box or Local Host)."""
        self.localhost_combo.set(mode)
    
    def get_html_file(self) -> str:
        """Get the selected HTML file."""
        return self.html_combo.get()
    
    def set_html_file(self, filename: str) -> None:
        """Set the selected HTML file."""
        self.html_combo.set(filename)
    
    def enable_html_dropdown(self, enabled: bool = True) -> None:
        """Enable or disable the HTML file dropdown."""
        self.html_combo.config(state="readonly" if enabled else tk.DISABLED)
    
    def get_debug_mode(self) -> str:
        """Get the debug mode (Debug/Normal)."""
        return self.debug_combo.get()
    
    def set_debug_mode(self, mode: str) -> None:
        """Set the debug mode (Debug or Normal)."""
        self.debug_combo.set(mode)
        # Update HTML dropdown based on debug mode
        is_debug = (mode == "Debug")
        self.html_combo.config(state="readonly" if is_debug else tk.DISABLED)


# Demo/Test code
if __name__ == "__main__":
    root = tk.Tk()
    root.title("OperationalPanel Demo")
    root.geometry("1200x200")
    
    # Mock settings for demo
    demo_settings = {
        'Board': {
            'Type': 'ControllinoMega',
            'AvailableTypes': ['ControllinoMega', 'ControllinoMini', 'ArduinoUno', 'none'],
            'simulation': True
        }
    }
    
    def mock_load():
        print("Load clicked")
        panel.set_connector("J1 - Loaded")
    
    def mock_keep_alive():
        print("KeepAlive clicked")
        panel.enable_test(True)
        panel.enable_monitor(True)
    
    def mock_i_bit():
        print("I_Bit clicked")
        panel.enable_stop_ibit(True)
        panel.enable_i_bit(False)
    
    def mock_run():
        print("Test clicked")
        panel.enable_stop_t(True)
        panel.enable_test(False)
    
    def mock_stop_ibit():
        print("Stop_IBIT clicked")
        panel.enable_stop_ibit(False)
        panel.enable_i_bit(True)
    
    def mock_stop():
        print("Stop_T clicked")
        panel.enable_stop_t(False)
        panel.enable_test(True)
    
    def mock_report():
        print("Report clicked")
        print(f"Hardware: {panel.get_hardware()}")
        print(f"Simulation: {panel.get_simulation_mode()}")
    
    def mock_clear():
        print("Clear Log clicked")
    
    def mock_hw_change(new_hw: str):
        print(f"Hardware changed to: {new_hw}")
        demo_settings['Board']['Type'] = new_hw
    
    def mock_simulate_change(new_mode: str):
        print(f"Simulation mode changed to: {new_mode}")
        demo_settings['Board']['simulation'] = (new_mode == "On")
    
    panel = OperationalPanel(
        root,
        on_load=mock_load,
        on_keep_alive=mock_keep_alive,
        on_i_bit=mock_i_bit,
        on_test=mock_run,
        on_stop_ibit=mock_stop_ibit,
        on_stop_t=mock_stop,
        on_report=mock_report,
        on_clear_log=mock_clear,
        settings=demo_settings,
        on_hw_change=mock_hw_change,
        on_simulate_change=mock_simulate_change
    )
    panel.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    root.mainloop()
